<!DOCTYPE html>
<html class="no-js">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>
            Better Boilerplate - Components Examples
        </title>

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="dns-prefetch" href="//code.jquery.com" />

        <link rel="stylesheet" href="dist/css/main.min.css">

    </head>

<body>